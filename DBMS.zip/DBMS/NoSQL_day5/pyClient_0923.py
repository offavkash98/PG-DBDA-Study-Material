from  pymongo import MongoClient

# connect with mongo db on port No 27017
client=MongoClient('mongodb://127.0.0.1:27017/')

# connect with database named as 'dbda'
db=client['dbda']

# connect with collection named as 'emp'
emp=db['emp']

# Print all the employee data from emp collection
# emps = emp.find()
# for e in emps:
#     print(e)

#Print all the employee data from emp collection using python function getAllEmp()
def getAllEmp():
    emps = emp.find()
    for e in emps:
        print(e['_id'], ',' ,e['ename'] , ',' ,e['job'], ',' , e['sal'])


#Print info of all MANAGER from emp collection using python function getAllManagers()
def getAllManagers():
    criteria={'job':'MANAGER'}
    emps=emp.find(criteria)
    for e in emps:
        print(e['_id'], ',' ,e['ename'] , ',' ,e['job'], ',' , e['sal'])

#add new emp as _id=101 , ename='nita' , job:"MANAGER" , sal:2000  , deptno:20
def addNewEmp():
    newEmp={'_id':101 , 'ename':'nita','job':"MANAGER",'sal':2000,'deptno':20}
    emp.insert_one(newEmp)
    print("Emp inserted .....")


def deleteEmp():
    empid=int(input("Enter emp id to delete from database"))
    criteria = {'_id':empid}
    emp.delete_one(criteria)
    print(f"Emp having id={empid} deleted .....")

#Change name of emp id 101 as "Neeta"
def updateEmp():
    emp.update_one({'_id':101},{'$set':{'ename':'Neeta'}})
    print("Emp updated .....")


# print name and sal of all emp sorted by sal using aggregation pipeline
def pipeline1():
    res=emp.aggregate([
        {
            '$sort':{'sal':1}
        },{
            '$project':{'ename':1 , 'sal': 1 , '_id':0 }
        }])
    for e in res:
        print(e)


def pipeline2():
    pipeline=[
        {
            '$sort':{'sal':1}
        },{
            '$project':{'ename':1 , 'sal': 1 , '_id':0 }
        }]
    res=emp.aggregate(pipeline)
    for e in res:
        print(e)

# find all the employees along with their commissions and calculate total salary
def pipeline3():
    pipeline=[{
        '$addFields':
            {
            'commission': { '$ifNull':[ '$comm', 0 ]}
            }
      },{
        '$addFields':
            {
              'totalSalary':{ '$add': ['$sal','$commission']}
            }
      },{
        '$project':{ 'ename':1, 'commission':1, 'sal':1 ,'totalSalary': 1, '_id':0}
      }]
    res = emp.aggregate(pipeline)
    for e in res:
        print(e)


# getAllEmp()
# getAllManagers()
# addNewEmp()
# getAllManagers()
# deleteEmp()
# updateEmp()
# getAllEmp()
# pipeline1()
pipeline3()