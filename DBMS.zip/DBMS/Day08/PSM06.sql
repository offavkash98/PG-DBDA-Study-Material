-- Q6. Write a stored procedure to square a given number
-- the number should be passed through INOUT parameter and the output should be taken out
-- from the same INOUT parameter

DROP PROCEDURE IF EXISTS sp_sqr2;

DELIMITER $$
CREATE PROCEDURE sp_sqr2(INOUT p_num INT)
BEGIN

SET p_num = p_num * p_num;

END;
$$

DELIMITER ;
-- SOURCE <path to PSM06.sql>
-- SELECT @res;
-- SET @res = 5;
-- CALL sp_sqr2(@res);