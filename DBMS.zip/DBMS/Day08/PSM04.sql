-- Q4. Write a stored procedure to calculate area of rectangle
-- pass the values of len and breadth from parameters
-- calculate and add the area inside the result table

DROP PROCEDURE IF EXISTS  sp_rectanglearea;
DELIMITER $$
CREATE PROCEDURE sp_rectanglearea(IN p_len INT, IN p_bre INT)
BEGIN

DECLARE v_area INT;

SET v_area = p_len * p_bre;

INSERT INTO result VALUES(v_area,"Area of Rectangle");

END;
$$
DELIMITER ;

-- SOURCE <path to PSM04.sql>
-- CALL sp_rectanglearea(10,5);