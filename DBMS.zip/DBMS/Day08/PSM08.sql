-- Q8. Write a stored procedure to sum of all the even numbers in the given range

DROP PROCEDURE IF EXISTS sp_sumeven;

DELIMITER $$
CREATE PROCEDURE sp_sumeven(IN p_low INT, IN p_high INT)
BEGIN
DECLARE v_sum INT DEFAULT 0;
DECLARE v_num INT;
SET v_num = p_low;

WHILE v_num<=p_high DO

IF v_num%2=0 THEN
SET v_sum = v_sum + v_num;
END IF;

SET v_num = v_num + 1;

END WHILE;

SELECT p_low AS lowValue, p_high AS highValue, v_sum AS `sum of even numbers`;

END;
$$

DELIMITER ;

-- SOURCE <path to PSM08.sql>
-- CALL sp_sumeven(1,30);