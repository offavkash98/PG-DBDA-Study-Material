-- write a triger that updates the balance automatically 
-- after insert is done inside the transaction table

DROP TRIGGER IF EXISTS updatebalance;
DELIMITER $$
CREATE TRIGGER updatebalance
AFTER INSERT ON transaction
FOR EACH ROW
BEGIN

IF NEW.type="DEPOSIT" THEN
    UPDATE accounts SET balance = balance + NEW.amount WHERE accid = NEW.accid;
ELSE
    UPDATE accounts SET balance = balance-NEW.amount WHERE accid =  NEW.accid;
END IF;

END;
$$

DELIMITER ;

-- SOURCE <path to PSM09.sql>