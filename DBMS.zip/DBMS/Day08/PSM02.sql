-- Q2. Write a stored procedure to insert hello world msg into result table

DROP PROCEDURE IF EXISTS sp_hello2;

DELIMITER $$
CREATE PROCEDURE sp_hello2()
BEGIN
INSERT INTO result VALUES(1,"Hello World");
END;
$$

DELIMITER ;

-- SOURCE <path to PSM02.sql>
-- CALL sp_hello2();