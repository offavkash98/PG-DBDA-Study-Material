-- Q5. Write a stored procedure to square a given number
-- the number should be passed through IN parameter and the output should be taken out
-- from the out parameter

DROP PROCEDURE IF EXISTS sp_sqr;

DELIMITER $$
CREATE PROCEDURE sp_sqr(IN p_num INT, OUT p_res INT)
BEGIN
SET p_res = p_num * p_num;
END;
$$

DELIMITER ;

-- SOURCE <path to PSM05.sql>
-- SELECT @res;
-- CALL sp_sqr(5,@res);