-- write a function called as TITLE()
-- it will accept a string value and convert first letter of it in  upper case
-- and rest of the string in lower case
-- title(SMITH) -> Smith 

DROP FUNCTION IF EXISTS TITLE;

DELIMITER $$
CREATE FUNCTION TITLE(p_name CHAR(40))
RETURNS CHAR(40)
DETERMINISTIC
BEGIN

DECLARE v_first CHAR(1);
DECLARE v_remaning CHAR(39);
DECLARE v_title CHAR(40);

SET v_first = UPPER(LEFT(p_name,1));
SET v_remaning = LOWER(SUBSTRING(p_name,2));
SET v_title  = CONCAT(v_first,v_remaning);

RETURN v_title;

END;
$$
DELIMITER ;

-- SOURCE <path to PSM10.sql>