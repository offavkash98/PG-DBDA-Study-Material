-- Q1. write a procedure that displays hello world on the terminal

DROP PROCEDURE IF EXISTS sp_hello;

DELIMITER $$
CREATE PROCEDURE sp_hello()
BEGIN
SELECT "Hello World" AS msg;
END;
$$

DELIMITER ;

-- SOURCE <path to PSM01.sql>
-- CALL sp_hello();