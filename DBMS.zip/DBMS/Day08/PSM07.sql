-- Q7. Write a stored procedure to check if a given number is even or odd

DROP PROCEDURE IF EXISTS sp_evenodd;

DELIMITER $$
CREATE PROCEDURE sp_evenodd(IN p_num INT)
BEGIN
IF p_num%2=0 THEN
SELECT CONCAT(p_num, " is even") AS msg;
ELSE
SELECT CONCAT(p_num, " is odd") AS msg;
END IF;
END;s
$$
DELIMITER ;
-- SOURCE <path to PSM07.sql>
-- CALL sp_evenodd(7);