-- Q3. Write a stored procedure to calculate area of circle
-- consider the radius as 7 

DROP PROCEDURE IF EXISTS  sp_circlearea;

DELIMITER $$
CREATE PROCEDURE sp_circlearea()
BEGIN

DECLARE radius INT DEFAULT 7;
DECLARE area DOUBLE;

SET area = 3.14 * radius * radius;

SELECT radius,area AS `Area of Circle`;

END;
$$
DELIMITER ;


-- SOURCE <path to PSM03.sql>
-- CALL sp_circlearea();