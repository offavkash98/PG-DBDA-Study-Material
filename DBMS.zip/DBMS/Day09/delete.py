import mysql.connector

mydb = mysql.connector.connect(
    host="localhost", username="mgr", password="mgr", database="classwork_db"
)

mycursor = mydb.cursor()
sql = "DELETE FROM emp WHERE empno=%s"
val = (1,)
mycursor.execute(sql, val)
mycursor.close()
mydb.commit()
