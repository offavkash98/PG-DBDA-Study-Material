import mysql.connector

mydb = mysql.connector.connect(
    host="localhost", username="mgr", password="mgr", database="classwork_db"
)

mycursor = mydb.cursor()
sql = "SELECT * FROM emp WHERE job = %s"
val = ("ANALYST",)
mycursor.execute(sql, val)
result = mycursor.fetchall()
mycursor.close()

for x in result:
    print(x)
