import mysql.connector

mydb = mysql.connector.connect(
    host="localhost", username="mgr", password="mgr", database="classwork_db"
)

mycursor = mydb.cursor()
sql = "UPDATE emp SET sal=%s WHERE empno=%s"
val = (2000, 1)
mycursor.execute(sql, val)
mycursor.close()
mydb.commit()
