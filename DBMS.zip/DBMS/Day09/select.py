import mysql.connector

mydb = mysql.connector.connect(
    host="localhost", username="root", password="root", database="classwork_db"
)

mycursor = mydb.cursor()

sql = "SELECT * FROM emp"
mycursor.execute(sql)
result = mycursor.fetchall()
mycursor.close()

for x in result:
    print(x)
