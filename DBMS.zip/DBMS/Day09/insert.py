import mysql.connector

mydb = mysql.connector.connect(
    host="localhost", username="mgr", password="mgr", database="classwork_db"
)

mycursor = mydb.cursor()
sql = "INSERT INTO emp(empno,ename,sal) VALUES(%s,%s,%s)"
val = (1, "rohan", 1000)
mycursor.execute(sql, val)
mycursor.close()
mydb.commit()
