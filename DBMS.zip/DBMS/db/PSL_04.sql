
DROP PROCEDURE IF EXISTS sp_rect_area;

DELIMITER $$

CREATE PROCEDURE sp_rect_area(IN L INT , IN B INT)

BEGIN

DECLARE area INT;
SET area = L*B;

INSERT INTO result VALUES(area ,"AREA");




END;

$$

DELIMITER ;

 

