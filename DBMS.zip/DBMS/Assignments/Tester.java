/**

Q1) Create Java application for fixed stack & growable stack based on Stack 
interface, for storing emp details. 
1.1 Create Employee class -- id,name,salary, constructor,toString
1.2 Stack interface -- push & pop functionality for Emp refs. & declare 
STACK_SIZE as a constant. 
1.3 Create implementation class of Stack i/f -- FixedStack (array based)
1.4 Create another implementation class of Stack i/f-- GrowableStack (array 
based)
1.5 Create Tester class (Hint : use dynamic method dispatch using 
interfaces)
Display Menu
Note : Must use 1 switch-case only. You won't need any complex nested 
control structure
Once user selects either fixed or growable stack , user shouldn't be allowed 
to change the selection of the stack.
(Hint : null checking)
1 -- Choose Fixed Stack
2 -- Choose Growable Stack
Accept following options only after initial selection.(Hint : null checking)
3 -- Push data 
I/P : Accept emp details & store these details in the earlier chosen stack or 
give error mesg : NO stack chosen !!!
4 --- Pop data & display the same (from the earlier chosen stack or give error 
mesg : NO stack chosen !!!)
No inputs are required : pop emp details from the top of the stack
5 -- Exit

**/

package assignment.com;

import java.util.Scanner;

public class Tester {
	static Scanner sc = new Scanner(System.in);
	static int choice;
	static boolean fixedStatus;
	static boolean growableStatus;
	static FixedStack<Employee> stack1 = new FixedStack<Employee>();
	static GrowableStack<Employee> stack2 = new GrowableStack<Employee>();

	public static void main(String[] args) {
		stack1.init();
		do {
			System.out.println("\n1. Choose Fixed Stack");
			System.out.println("2. Choose Growable Stack");
			System.out.println("3. Push Data");
			System.out.println("4. Pop Data");
			System.out.println("5. Exit");
			System.out.println("Enter your choice");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Inside Fixed Stack");
				if(growableStatus == false) {
				fixedStatus = true;
				}else
				{
					System.out.println("Stack type is Growable!!! \n Cannot Change Stack Type");
				}
				break;
			case 2:
				System.out.println("Inside Growable Stack");
				if(fixedStatus == false) {
				growableStatus = true;
				}else
				{
					System.out.println("Stack type is Fixed!!! \n Cannot Change Stack Type");
				}
				break;
			case 3:
				System.out.println("Inside Push Data");
				if (fixedStatus) {
					if (stack1.isFull() == false) {
						Employee e = stack1.acceptRecord();
						stack1.push(e);

						
					} else {
						System.out.println("Cannot push, Stack is full");
					}
				}
				if (growableStatus) {
					if (stack2.isFull() == false) {
						stack2.increaseSize();
					}
					Employee e = stack2.acceptRecord();
					stack2.push(e);

					for (int i = 0; i < GrowableStack.stackAr.length; i++) {
						System.out.println(GrowableStack.stackAr[i] + " ");
					}
				}
				break;
			case 4:
				System.out.println("Inside Pop Data");
				if (stack1.isEmpty() == false) {
					if (fixedStatus) {
						FixedStack<Employee> stack1 = new FixedStack<Employee>();
						stack1.pop();
					}
				} else {
					System.out.println("Stack is empty");
				}
				if (stack2.isEmpty() == false) {
					if (growableStatus) {
						GrowableStack<Employee> stack2 = new GrowableStack<Employee>();
						stack2.pop();
					}
				} else {
					System.out.println("Stack is empty");
				}
				break;
			case 5:
				System.out.println("Inside Exit");
				choice = 5;
				break;
			}
		} while (choice != 5);
	}
}

