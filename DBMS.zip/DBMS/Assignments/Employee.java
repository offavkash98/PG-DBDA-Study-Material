/**

Q1) Create Java application for fixed stack & growable stack based on Stack 
interface, for storing emp details. 
1.1 Create Employee class -- id,name,salary, constructor,toString
1.2 Stack interface -- push & pop functionality for Emp refs. & declare 
STACK_SIZE as a constant. 
1.3 Create implementation class of Stack i/f -- FixedStack (array based)
1.4 Create another implementation class of Stack i/f-- GrowableStack (array 
based)
1.5 Create Tester class (Hint : use dynamic method dispatch using 
interfaces)
Display Menu
Note : Must use 1 switch-case only. You won't need any complex nested 
control structure
Once user selects either fixed or growable stack , user shouldn't be allowed 
to change the selection of the stack.
(Hint : null checking)
1 -- Choose Fixed Stack
2 -- Choose Growable Stack
Accept following options only after initial selection.(Hint : null checking)
3 -- Push data 
I/P : Accept emp details & store these details in the earlier chosen stack or 
give error mesg : NO stack chosen !!!
4 --- Pop data & display the same (from the earlier chosen stack or give error 
mesg : NO stack chosen !!!)
No inputs are required : pop emp details from the top of the stack
5 -- Exit

**/

package assignment.com;

import java.util.Scanner;

public class Employee {

	private int id;
	private String name;
	private double salary;
	static Scanner sc = new Scanner(System.in);

	public Employee() {
		this.id = 0;
		this.name = "";
		this.salary = 0.0;
	}

	public Employee(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}

	public void acceptRecord() {
		System.out.println("Enter Employee ID : ");
		this.id = sc.nextInt();
		System.out.println("Enter Employee Name : ");
		this.name = sc.next();
		System.out.println("Enter Employee Salary : ");
		this.salary = sc.nextDouble();
	}

}
